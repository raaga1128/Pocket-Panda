import { NavLink } from 'react-router-dom';
import { Home, CreditCard, Clock, Wallet, User, Settings, X } from 'lucide-react';
import { motion } from 'framer-motion';

interface SidebarProps {
  onClose?: () => void;
}

const Sidebar = ({ onClose }: SidebarProps) => {
  const navItems = [
    { to: '/', icon: <Home size={20} />, label: 'Dashboard' },
    { to: '/accounts', icon: <CreditCard size={20} />, label: 'Accounts' },
    { to: '/transactions', icon: <Clock size={20} />, label: 'Transactions' },
    { to: '/wallet', icon: <Wallet size={20} />, label: 'Wallets' },
    { to: '/profile', icon: <User size={20} />, label: 'Profile' },
  ];

  return (
    <aside className="w-64 h-full bg-white dark:bg-gray-800 shadow-md z-20">
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="h-10 w-10 bg-primary-600 rounded-lg flex items-center justify-center">
            <Wallet className="h-6 w-6 text-white" />
          </div>
          <span className="text-xl font-semibold">Pocket Panda</span>
        </div>
        {onClose && (
          <button
            onClick={onClose}
            className="md:hidden p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700"
            aria-label="Close sidebar"
          >
            <X size={20} />
          </button>
        )}
      </div>
      
      <div className="px-3 py-2">
        <div className="space-y-1">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) => `
                flex items-center px-3 py-3 rounded-lg text-sm font-medium
                ${isActive 
                  ? 'bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-400' 
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700/50'}
                transition-colors duration-150
              `}
            >
              <span className="mr-3">{item.icon}</span>
              {item.label}
            </NavLink>
          ))}
        </div>
      </div>
      
      <div className="absolute bottom-0 w-full p-4 border-t border-gray-200 dark:border-gray-700">
        <div className="rounded-lg bg-primary-50 dark:bg-gray-700 p-4">
          <h4 className="font-medium mb-2">Need help?</h4>
          <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">
            Contact our support team for assistance
          </p>
          <button className="w-full px-3 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg text-sm font-medium transition-colors duration-150">
            Contact Support
          </button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;