import { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { motion } from 'framer-motion';

// Mock data for spending by category
const spendingByCategory = [
  { category: 'Food & Dining', amount: 450.75, color: '#6a5acd' },
  { category: 'Shopping', amount: 320.50, color: '#4ade80' },
  { category: 'Travel', amount: 250.00, color: '#f59e0b' },
  { category: 'Entertainment', amount: 180.25, color: '#ef4444' },
  { category: 'Bills', amount: 520.00, color: '#3b82f6' },
  { category: 'Others', amount: 150.50, color: '#ec4899' },
];

// Mock data for spending by month
const spendingByMonth = [
  { month: 'Jan', amount: 1250 },
  { month: 'Feb', amount: 1400 },
  { month: 'Mar', amount: 1180 },
  { month: 'Apr', amount: 1550 },
  { month: 'May', amount: 1320 },
  { month: 'Jun', amount: 1100 },
];

const chartColors = ['#6a5acd', '#4ade80', '#f59e0b', '#ef4444', '#3b82f6', '#ec4899'];

// Custom tooltip for charts
const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white dark:bg-gray-800 p-3 border border-gray-200 dark:border-gray-700 rounded-lg shadow-md">
        <p className="text-sm font-medium">{label}</p>
        <p className="text-sm text-primary-600 dark:text-primary-400">
          ${payload[0].value.toFixed(2)}
        </p>
      </div>
    );
  }
  
  return null;
};

const SpendingOverview = () => {
  const [activeTab, setActiveTab] = useState('category');
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <h2 className="text-xl font-semibold">Spending Overview</h2>
        
        <div className="flex space-x-1 bg-gray-100 dark:bg-gray-700 p-1 rounded-lg">
          <button 
            className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
              activeTab === 'category' 
                ? 'bg-white dark:bg-gray-800 shadow-sm' 
                : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
            }`}
            onClick={() => setActiveTab('category')}
          >
            By Category
          </button>
          <button 
            className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
              activeTab === 'month' 
                ? 'bg-white dark:bg-gray-800 shadow-sm' 
                : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
            }`}
            onClick={() => setActiveTab('month')}
          >
            Monthly Trend
          </button>
        </div>
      </div>
      
      <div className="h-72">
        {activeTab === 'category' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="h-full"
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={spendingByCategory}
                layout="vertical"
                margin={{ top: 5, right: 30, left: 60, bottom: 5 }}
              >
                <XAxis type="number" />
                <YAxis dataKey="category" type="category" tickLine={false} axisLine={false} width={120} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="amount" radius={[0, 4, 4, 0]}>
                  {spendingByCategory.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </motion.div>
        )}
        
        {activeTab === 'month' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="h-full"
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={spendingByMonth}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="amount" fill="#6a5acd" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default SpendingOverview;