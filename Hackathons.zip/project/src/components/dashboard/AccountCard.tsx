import { motion } from 'framer-motion';
import { Account } from '../../types';

interface AccountCardProps {
  account: Account;
  isSelected: boolean;
  onClick: () => void;
}

const AccountCard = ({ account, isSelected, onClick }: AccountCardProps) => {
  return (
    <motion.div
      whileHover={{ y: -4, scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={`
        relative rounded-xl p-5 cursor-pointer transition-all duration-300
        ${isSelected 
          ? 'ring-2 ring-primary-500 dark:ring-primary-400 shadow-md' 
          : 'hover:shadow-md'}
      `}
      style={{ 
        background: `linear-gradient(135deg, ${account.color}, ${account.color}dd)`,
        color: 'white'
      }}
    >
      <div className="h-full flex flex-col justify-between">
        <div>
          <div className="flex items-center mb-1">
            {account.type === 'checking' && (
              <span className="text-2xl mr-2">💳</span>
            )}
            {account.type === 'savings' && (
              <span className="text-2xl mr-2">🏦</span>
            )}
            {account.type === 'investment' && (
              <span className="text-2xl mr-2">📈</span>
            )}
            <span className="text-lg font-medium">{account.type.charAt(0).toUpperCase() + account.type.slice(1)}</span>
          </div>
          <h3 className="font-medium text-sm mb-4 opacity-90">{account.name}</h3>
        </div>
        
        <div>
          <p className="text-2xl font-semibold mb-1">${account.balance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
          <p className="text-xs opacity-80">{account.number}</p>
        </div>
      </div>
      
      {/* Card decoration */}
      <div className="absolute top-0 right-0 h-full w-1/2 overflow-hidden pointer-events-none">
        <div 
          className="absolute inset-0 opacity-10" 
          style={{ 
            background: 'radial-gradient(circle at 70% 30%, white 0%, transparent 70%)' 
          }}
        ></div>
      </div>
    </motion.div>
  );
};

export default AccountCard;