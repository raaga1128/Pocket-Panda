import { useState, useMemo } from 'react';
import { Search, Calendar, Filter, Download, ChevronDown } from 'lucide-react';
import { format } from 'date-fns';
import { motion } from 'framer-motion';

// Mock data
const transactions = [
  { 
    id: '1', 
    title: 'Starbucks', 
    date: new Date('2025-01-15'), 
    amount: -4.85, 
    category: 'Food & Drink', 
    account: 'Primary Checking',
    description: 'Coffee and bagel',
    icon: '☕',
  },
  { 
    id: '2', 
    title: 'Amazon', 
    date: new Date('2025-01-14'), 
    amount: -65.28, 
    category: 'Shopping', 
    account: 'Primary Checking',
    description: 'Household items',
    icon: '🛍️',
  },
  { 
    id: '3', 
    title: 'Salary', 
    date: new Date('2025-01-12'), 
    amount: 2750.00, 
    category: 'Income', 
    account: 'Primary Checking',
    description: 'Monthly salary',
    icon: '💰',
  },
  { 
    id: '4', 
    title: 'Netflix', 
    date: new Date('2025-01-10'), 
    amount: -13.99, 
    category: 'Entertainment', 
    account: 'Primary Checking',
    description: 'Monthly subscription',
    icon: '🎬',
  },
  { 
    id: '5', 
    title: 'Grocery Store', 
    date: new Date('2025-01-08'), 
    amount: -87.62, 
    category: 'Groceries', 
    account: 'Primary Checking',
    description: 'Weekly groceries',
    icon: '🛒',
  },
  { 
    id: '6', 
    title: 'Transfer to Savings', 
    date: new Date('2025-01-01'), 
    amount: -500.00, 
    category: 'Transfer', 
    account: 'Primary Checking',
    description: 'Monthly savings transfer',
    icon: '📤',
  },
  { 
    id: '7', 
    title: 'Interest Payment', 
    date: new Date('2024-12-31'), 
    amount: 3.50, 
    category: 'Interest', 
    account: 'Savings',
    description: 'Monthly interest',
    icon: '💹',
  },
  { 
    id: '8', 
    title: 'Gas Station', 
    date: new Date('2024-12-28'), 
    amount: -42.15, 
    category: 'Transportation', 
    account: 'Primary Checking',
    description: 'Fuel',
    icon: '⛽',
  },
  { 
    id: '9', 
    title: 'Phone Bill', 
    date: new Date('2024-12-25'), 
    amount: -65.00, 
    category: 'Bills & Utilities', 
    account: 'Primary Checking',
    description: 'Monthly phone bill',
    icon: '📱',
  },
  { 
    id: '10', 
    title: 'Stock Purchase - AAPL', 
    date: new Date('2024-12-15'), 
    amount: -1500.00, 
    category: 'Investment', 
    account: 'Investment',
    description: 'Apple stock purchase',
    icon: '📈',
  },
  { 
    id: '11', 
    title: 'Dividend Payment', 
    date: new Date('2024-12-10'), 
    amount: 125.65, 
    category: 'Dividend', 
    account: 'Investment',
    description: 'Quarterly dividends',
    icon: '💰',
  },
  { 
    id: '12', 
    title: 'Restaurant', 
    date: new Date('2024-12-05'), 
    amount: -85.24, 
    category: 'Food & Drink', 
    account: 'Primary Checking',
    description: 'Dinner with friends',
    icon: '🍽️',
  },
];

// Categories
const categories = [
  'All',
  'Food & Drink',
  'Shopping',
  'Transportation',
  'Bills & Utilities',
  'Entertainment',
  'Income',
  'Transfer',
  'Investment',
  'Dividend',
  'Interest',
];

// Accounts
const accounts = [
  'All Accounts',
  'Primary Checking',
  'Savings',
  'Investment',
];

const Transactions = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedAccount, setSelectedAccount] = useState('All Accounts');
  const [dateRange, setDateRange] = useState({ from: null, to: null });
  const [expandedTransaction, setExpandedTransaction] = useState<string | null>(null);
  
  const handleTransactionClick = (id: string) => {
    setExpandedTransaction(prevId => prevId === id ? null : id);
  };
  
  const filteredTransactions = useMemo(() => {
    return transactions.filter(transaction => {
      const matchesSearch = transaction.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          transaction.description.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesCategory = selectedCategory === 'All' || transaction.category === selectedCategory;
      
      const matchesAccount = selectedAccount === 'All Accounts' || transaction.account === selectedAccount;
      
      return matchesSearch && matchesCategory && matchesAccount;
    });
  }, [searchTerm, selectedCategory, selectedAccount, dateRange]);
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold">Transactions</h1>
        <button className="flex items-center text-sm bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700 py-2 px-4 rounded-lg transition-colors">
          <Download size={16} className="mr-1" /> Export
        </button>
      </div>
      
      {/* Filters */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
        <div className="flex flex-col lg:flex-row gap-4">
          {/* Search */}
          <div className="relative flex-1">
            <Search size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search transactions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 dark:focus:ring-primary-400"
            />
          </div>
          
          {/* Category filter */}
          <div className="relative">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="pl-4 pr-10 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg text-sm appearance-none w-full focus:outline-none focus:ring-2 focus:ring-primary-500 dark:focus:ring-primary-400"
            >
              {categories.map(category => (
                <option key={category} value={category}>{category}</option>
              ))}
            </select>
            <ChevronDown size={16} className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none" />
          </div>
          
          {/* Account filter */}
          <div className="relative">
            <select
              value={selectedAccount}
              onChange={(e) => setSelectedAccount(e.target.value)}
              className="pl-4 pr-10 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg text-sm appearance-none w-full focus:outline-none focus:ring-2 focus:ring-primary-500 dark:focus:ring-primary-400"
            >
              {accounts.map(account => (
                <option key={account} value={account}>{account}</option>
              ))}
            </select>
            <ChevronDown size={16} className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none" />
          </div>
          
          {/* Date filter - simplified for now */}
          <button className="flex items-center text-sm bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-650 py-2 px-4 rounded-lg">
            <Calendar size={16} className="mr-2" /> All Dates <ChevronDown size={16} className="ml-2" />
          </button>
        </div>
      </div>
      
      {/* Transactions list */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex justify-between items-center">
            <h2 className="text-lg font-semibold">All Transactions</h2>
            <span className="text-sm text-gray-500 dark:text-gray-400">{filteredTransactions.length} transactions</span>
          </div>
        </div>
        
        <div className="divide-y divide-gray-200 dark:divide-gray-700">
          {filteredTransactions.length > 0 ? (
            filteredTransactions.map((transaction) => (
              <motion.div
                key={transaction.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                layout
                onClick={() => handleTransactionClick(transaction.id)}
                className="p-4 hover:bg-gray-50 dark:hover:bg-gray-750 cursor-pointer transition-colors"
              >
                <div className="flex items-center">
                  <div className="flex-shrink-0 h-10 w-10 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center mr-4">
                    <span className="text-xl">{transaction.icon}</span>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between">
                      <p className="text-sm font-medium truncate">{transaction.title}</p>
                      <p className={`text-sm font-medium ${
                        transaction.amount > 0 
                          ? 'text-green-600 dark:text-green-400' 
                          : 'text-red-600 dark:text-red-400'
                      }`}>
                        {transaction.amount > 0 ? '+' : ''}
                        ${Math.abs(transaction.amount).toFixed(2)}
                      </p>
                    </div>
                    <div className="flex justify-between">
                      <div className="flex items-center mt-1">
                        <span className="text-xs px-2 py-0.5 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 mr-2">
                          {transaction.category}
                        </span>
                        <span className="text-xs text-gray-500 dark:text-gray-400">
                          {format(transaction.date, 'MMM dd, yyyy')}
                        </span>
                      </div>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        {transaction.account}
                      </p>
                    </div>
                  </div>
                </div>
                
                {expandedTransaction === transaction.id && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="mt-3 pt-3 border-t border-gray-200 dark:border-gray-700"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <h4 className="text-xs text-gray-500 dark:text-gray-400 mb-1">Description</h4>
                        <p className="text-sm">{transaction.description}</p>
                      </div>
                      <div>
                        <h4 className="text-xs text-gray-500 dark:text-gray-400 mb-1">Date & Time</h4>
                        <p className="text-sm">{format(transaction.date, 'MMM dd, yyyy')}</p>
                      </div>
                      <div>
                        <h4 className="text-xs text-gray-500 dark:text-gray-400 mb-1">Transaction ID</h4>
                        <p className="text-sm">#{(Math.random() * 1000000).toFixed(0).padStart(7, '0')}</p>
                      </div>
                    </div>
                    <div className="flex justify-end mt-3">
                      <button className="text-xs text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 mr-3">
                        Edit Category
                      </button>
                      <button className="text-xs text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300">
                        Add Note
                      </button>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            ))
          ) : (
            <div className="p-6 text-center">
              <p className="text-gray-500 dark:text-gray-400">No transactions found</p>
            </div>
          )}
        </div>
        
        {filteredTransactions.length > 0 && (
          <div className="px-6 py-4 border-t border-gray-200 dark:border-gray-700">
            <div className="flex justify-between items-center">
              <button className="text-sm text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300">
                Previous
              </button>
              <span className="text-sm text-gray-500 dark:text-gray-400">Page 1 of 1</span>
              <button className="text-sm text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300">
                Next
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Transactions;