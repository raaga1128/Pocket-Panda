import { useState } from 'react';
import { CreditCard, Wallet, Plus, ChevronRight, DollarSign, Settings, BarChart4 } from 'lucide-react';
import { motion } from 'framer-motion';

// Types
import { Account } from '../types';

// Mock data
const accounts: Account[] = [
  {
    id: '1',
    name: 'Primary Checking',
    type: 'checking',
    balance: 3458.23,
    number: '**** 4587',
    color: '#6a5acd',
  },
  {
    id: '2',
    name: 'Savings',
    type: 'savings',
    balance: 12750.89,
    number: '**** 7621',
    color: '#4ade80',
  },
  {
    id: '3',
    name: 'Investment',
    type: 'investment',
    balance: 32750.48,
    number: '**** 9354',
    color: '#f59e0b',
  }
];

// Additional data for the selected account
const accountDetails = {
  '1': {
    bank: 'Chase Bank',
    accountType: 'Checking',
    interestRate: '0.01%',
    openedDate: 'January 15, 2023',
    transactions: [
      { id: 1, title: 'Starbucks', date: 'Jan 15, 2025', amount: -4.85, category: 'Food & Drink' },
      { id: 2, title: 'Amazon', date: 'Jan 14, 2025', amount: -65.28, category: 'Shopping' },
      { id: 3, title: 'Payroll Deposit', date: 'Jan 12, 2025', amount: 2750.00, category: 'Income' },
      { id: 4, title: 'Netflix', date: 'Jan 10, 2025', amount: -13.99, category: 'Entertainment' },
      { id: 5, title: 'Grocery Store', date: 'Jan 08, 2025', amount: -87.62, category: 'Groceries' },
    ]
  },
  '2': {
    bank: 'Wells Fargo',
    accountType: 'Savings',
    interestRate: '0.35%',
    openedDate: 'March 10, 2022',
    transactions: [
      { id: 1, title: 'Transfer from Checking', date: 'Jan 01, 2025', amount: 500.00, category: 'Transfer' },
      { id: 2, title: 'Interest Payment', date: 'Dec 31, 2024', amount: 3.50, category: 'Interest' },
      { id: 3, title: 'Transfer from Checking', date: 'Dec 01, 2024', amount: 500.00, category: 'Transfer' },
      { id: 4, title: 'Interest Payment', date: 'Nov 30, 2024', amount: 3.15, category: 'Interest' },
    ]
  },
  '3': {
    bank: 'Fidelity',
    accountType: 'Investment',
    interestRate: 'Variable',
    openedDate: 'June 5, 2021',
    transactions: [
      { id: 1, title: 'Stock Purchase - AAPL', date: 'Jan 10, 2025', amount: -1500.00, category: 'Investment' },
      { id: 2, title: 'Dividend Payment', date: 'Jan 5, 2025', amount: 125.65, category: 'Dividend' },
      { id: 3, title: 'Stock Sale - MSFT', date: 'Dec 15, 2024', amount: 2250.00, category: 'Investment' },
      { id: 4, title: 'Deposit', date: 'Dec 1, 2024', amount: 1000.00, category: 'Deposit' },
    ]
  }
};

const Accounts = () => {
  const [selectedAccount, setSelectedAccount] = useState<string>(accounts[0].id);
  const [activeTab, setActiveTab] = useState<string>('transactions');
  
  const getSelectedAccount = () => {
    return accounts.find(account => account.id === selectedAccount);
  };
  
  const getAccountDetails = () => {
    return accountDetails[selectedAccount as keyof typeof accountDetails];
  };
  
  const account = getSelectedAccount();
  const details = getAccountDetails();
  
  if (!account || !details) {
    return <div>Account not found</div>;
  }
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold">Accounts</h1>
        <button className="flex items-center text-sm bg-primary-600 hover:bg-primary-700 text-white py-2 px-4 rounded-lg transition-colors">
          <Plus size={16} className="mr-1" /> Add Account
        </button>
      </div>
      
      {/* Account cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {accounts.map(account => (
          <motion.div
            key={account.id}
            whileHover={{ y: -4, scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setSelectedAccount(account.id)}
            className={`
              relative rounded-xl p-5 cursor-pointer transition-all duration-300
              ${selectedAccount === account.id 
                ? 'ring-2 ring-primary-500 dark:ring-primary-400 shadow-md' 
                : 'hover:shadow-md'}
            `}
            style={{ 
              background: `linear-gradient(135deg, ${account.color}, ${account.color}dd)`,
              color: 'white'
            }}
          >
            <div className="h-full flex flex-col justify-between">
              <div>
                <div className="flex items-center mb-1">
                  {account.type === 'checking' && (
                    <span className="text-2xl mr-2">💳</span>
                  )}
                  {account.type === 'savings' && (
                    <span className="text-2xl mr-2">🏦</span>
                  )}
                  {account.type === 'investment' && (
                    <span className="text-2xl mr-2">📈</span>
                  )}
                  <span className="text-lg font-medium">{account.type.charAt(0).toUpperCase() + account.type.slice(1)}</span>
                </div>
                <h3 className="font-medium text-sm mb-4 opacity-90">{account.name}</h3>
              </div>
              
              <div>
                <p className="text-2xl font-semibold mb-1">${account.balance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                <p className="text-xs opacity-80">{account.number}</p>
              </div>
            </div>
            
            {/* Card decoration */}
            <div className="absolute top-0 right-0 h-full w-1/2 overflow-hidden pointer-events-none">
              <div 
                className="absolute inset-0 opacity-10" 
                style={{ 
                  background: 'radial-gradient(circle at 70% 30%, white 0%, transparent 70%)' 
                }}
              ></div>
            </div>
          </motion.div>
        ))}
      </div>
      
      {/* Account details */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden">
        <div className="border-b border-gray-200 dark:border-gray-700">
          <div className="p-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-center">
                <div 
                  className="w-12 h-12 rounded-lg flex items-center justify-center mr-4 text-white"
                  style={{ backgroundColor: account.color }}
                >
                  {account.type === 'checking' && <CreditCard size={24} />}
                  {account.type === 'savings' && <Wallet size={24} />}
                  {account.type === 'investment' && <BarChart4 size={24} />}
                </div>
                <div>
                  <h2 className="text-xl font-semibold">{account.name}</h2>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{details.bank} • {account.number}</p>
                </div>
              </div>
              
              <div className="flex space-x-2">
                <button className="flex items-center text-sm bg-primary-600 hover:bg-primary-700 text-white py-2 px-4 rounded-lg transition-colors">
                  <DollarSign size={16} className="mr-1" /> Transfer
                </button>
                <button className="flex items-center text-sm border border-gray-300 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700 py-2 px-4 rounded-lg transition-colors">
                  <Settings size={16} className="mr-1" /> Manage
                </button>
              </div>
            </div>
          </div>
          
          <div className="px-6 flex space-x-4 overflow-x-auto">
            <button
              className={`py-3 text-sm font-medium border-b-2 transition-colors ${
                activeTab === 'transactions'
                  ? 'border-primary-600 text-primary-600 dark:border-primary-400 dark:text-primary-400'
                  : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
              onClick={() => setActiveTab('transactions')}
            >
              Transactions
            </button>
            <button
              className={`py-3 text-sm font-medium border-b-2 transition-colors ${
                activeTab === 'details'
                  ? 'border-primary-600 text-primary-600 dark:border-primary-400 dark:text-primary-400'
                  : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
              onClick={() => setActiveTab('details')}
            >
              Account Details
            </button>
            <button
              className={`py-3 text-sm font-medium border-b-2 transition-colors ${
                activeTab === 'statements'
                  ? 'border-primary-600 text-primary-600 dark:border-primary-400 dark:text-primary-400'
                  : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
              onClick={() => setActiveTab('statements')}
            >
              Statements
            </button>
          </div>
        </div>
        
        <div className="p-6">
          {activeTab === 'transactions' && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <h3 className="text-lg font-medium mb-4">Recent Transactions</h3>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                  <thead>
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Transaction
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Category
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Date
                      </th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Amount
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                    {details.transactions.map((transaction) => (
                      <tr key={transaction.id} className="hover:bg-gray-50 dark:hover:bg-gray-750">
                        <td className="px-4 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium">{transaction.title}</div>
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          <span className="px-2 py-1 text-xs rounded-full bg-gray-100 dark:bg-gray-700">
                            {transaction.category}
                          </span>
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                          {transaction.date}
                        </td>
                        <td className={`px-4 py-4 whitespace-nowrap text-sm font-medium text-right ${
                          transaction.amount > 0 
                            ? 'text-green-600 dark:text-green-400' 
                            : 'text-red-600 dark:text-red-400'
                        }`}>
                          {transaction.amount > 0 ? '+' : ''}
                          ${Math.abs(transaction.amount).toFixed(2)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="mt-6 flex justify-center">
                <button className="flex items-center text-sm text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300">
                  View all transactions <ChevronRight size={16} className="ml-1" />
                </button>
              </div>
            </motion.div>
          )}
          
          {activeTab === 'details' && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <h3 className="text-lg font-medium mb-4">Account Details</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Account Number</h4>
                    <p className="font-medium">{account.number}</p>
                  </div>
                  <div>
                    <h4 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Bank Name</h4>
                    <p className="font-medium">{details.bank}</p>
                  </div>
                  <div>
                    <h4 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Account Type</h4>
                    <p className="font-medium">{details.accountType}</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Current Balance</h4>
                    <p className="font-medium">${account.balance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  </div>
                  <div>
                    <h4 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Interest Rate</h4>
                    <p className="font-medium">{details.interestRate}</p>
                  </div>
                  <div>
                    <h4 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Date Opened</h4>
                    <p className="font-medium">{details.openedDate}</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
                <h3 className="text-lg font-medium mb-4">Account Settings</h3>
                
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-4 bg-gray-50 dark:bg-gray-750 rounded-lg">
                    <div>
                      <h4 className="font-medium">Overdraft Protection</h4>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Cover potential overdrafts with your linked savings account
                      </p>
                    </div>
                    <div className="relative inline-block w-12 h-6 transition duration-200 ease-in-out rounded-full">
                      <input
                        type="checkbox"
                        id="overdraft-protection"
                        className="absolute w-0 h-0 opacity-0"
                      />
                      <label
                        htmlFor="overdraft-protection"
                        className="flex items-center justify-between h-6 rounded-full cursor-pointer bg-gray-300 dark:bg-gray-600"
                      >
                        <span className="block h-5 w-5 ml-0.5 rounded-full bg-white transform transition-transform duration-200"></span>
                      </label>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center p-4 bg-gray-50 dark:bg-gray-750 rounded-lg">
                    <div>
                      <h4 className="font-medium">Paper Statements</h4>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Receive monthly paper statements by mail
                      </p>
                    </div>
                    <div className="relative inline-block w-12 h-6 transition duration-200 ease-in-out rounded-full">
                      <input
                        type="checkbox"
                        id="paper-statements"
                        className="absolute w-0 h-0 opacity-0"
                      />
                      <label
                        htmlFor="paper-statements"
                        className="flex items-center justify-between h-6 rounded-full cursor-pointer bg-gray-300 dark:bg-gray-600"
                      >
                        <span className="block h-5 w-5 ml-0.5 rounded-full bg-white transform transition-transform duration-200"></span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
          
          {activeTab === 'statements' && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <h3 className="text-lg font-medium mb-4">Account Statements</h3>
              
              <div className="space-y-3">
                {[
                  { month: 'January 2025', date: 'Jan 31, 2025', size: '2.4 MB' },
                  { month: 'December 2024', date: 'Dec 31, 2024', size: '2.1 MB' },
                  { month: 'November 2024', date: 'Nov 30, 2024', size: '1.9 MB' },
                  { month: 'October 2024', date: 'Oct 31, 2024', size: '2.3 MB' },
                  { month: 'September 2024', date: 'Sep 30, 2024', size: '2.0 MB' },
                ].map((statement, index) => (
                  <div 
                    key={index} 
                    className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-750 transition-colors"
                  >
                    <div>
                      <h4 className="font-medium">{statement.month} Statement</h4>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Generated on {statement.date} • {statement.size}
                      </p>
                    </div>
                    <button className="flex items-center text-sm text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300">
                      Download
                    </button>
                  </div>
                ))}
              </div>
              
              <div className="mt-6 flex justify-center">
                <button className="flex items-center text-sm text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300">
                  View older statements <ChevronRight size={16} className="ml-1" />
                </button>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Accounts;