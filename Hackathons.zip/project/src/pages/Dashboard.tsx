import { useState } from 'react';
import { CreditCard, DollarSign, ArrowUpRight, ArrowDownRight, Calendar, Send, TrendingUp, Plus } from 'lucide-react';
import { motion } from 'framer-motion';

// Components
import AccountCard from '../components/dashboard/AccountCard';
import SpendingOverview from '../components/dashboard/SpendingOverview';
import RecentTransactions from '../components/dashboard/RecentTransactions';
import QuickActions from '../components/dashboard/QuickActions';

// Types
import { Account, Transaction } from '../types';

// Mock data
const accounts: Account[] = [
  {
    id: '1',
    name: 'Primary Checking',
    type: 'checking',
    balance: 3458.23,
    number: '**** 4587',
    color: '#6a5acd',
  },
  {
    id: '2',
    name: 'Savings',
    type: 'savings',
    balance: 12750.89,
    number: '**** 7621',
    color: '#4ade80',
  },
  {
    id: '3',
    name: 'Investment',
    type: 'investment',
    balance: 32750.48,
    number: '**** 9354',
    color: '#f59e0b',
  }
];

const recentTransactions: Transaction[] = [
  {
    id: '1',
    title: 'Starbucks',
    date: new Date('2025-01-15'),
    amount: -4.85,
    category: 'Food & Drink',
    icon: '☕',
  },
  {
    id: '2',
    title: 'Amazon',
    date: new Date('2025-01-14'),
    amount: -65.28,
    category: 'Shopping',
    icon: '🛍️',
  },
  {
    id: '3',
    title: 'Salary',
    date: new Date('2025-01-12'),
    amount: 2750.00,
    category: 'Income',
    icon: '💰',
  },
  {
    id: '4',
    title: 'Netflix',
    date: new Date('2025-01-10'),
    amount: -13.99,
    category: 'Entertainment',
    icon: '🎬',
  },
  {
    id: '5',
    title: 'Grocery Store',
    date: new Date('2025-01-08'),
    amount: -87.62,
    category: 'Groceries',
    icon: '🛒',
  }
];

const quickActions = [
  { id: '1', title: 'Transfer', icon: <Send size={20} /> },
  { id: '2', title: 'Pay Bills', icon: <Calendar size={20} /> },
  { id: '3', title: 'Add Money', icon: <DollarSign size={20} /> },
  { id: '4', title: 'Investments', icon: <TrendingUp size={20} /> },
];

const Dashboard = () => {
  const [selectedAccount, setSelectedAccount] = useState(accounts[0].id);
  
  const totalBalance = accounts.reduce((total, account) => total + account.balance, 0);
  const totalIncome = 3250.00; // Mock data
  const totalExpenses = 1432.75; // Mock data
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: { type: 'spring', stiffness: 300, damping: 25 }
    }
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold">Dashboard</h1>
        <span className="text-sm text-gray-500 dark:text-gray-400">Last updated: Today, 10:45 AM</span>
      </div>
      
      {/* Overview cards */}
      <motion.div variants={itemVariants} className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="rounded-full p-3 bg-blue-100 dark:bg-blue-900/30 text-blue-500 dark:text-blue-400 mr-4">
                <CreditCard size={20} />
              </div>
              <span className="text-sm text-gray-500 dark:text-gray-400">Total Balance</span>
            </div>
            <span className="text-xs py-1 px-2 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-full flex items-center">
              <ArrowUpRight size={12} className="mr-1" /> 3.2%
            </span>
          </div>
          <div className="mt-4">
            <h3 className="text-2xl font-semibold">${totalBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h3>
            <span className="text-xs text-gray-500 dark:text-gray-400">Across all accounts</span>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="rounded-full p-3 bg-green-100 dark:bg-green-900/30 text-green-500 dark:text-green-400 mr-4">
                <ArrowUpRight size={20} />
              </div>
              <span className="text-sm text-gray-500 dark:text-gray-400">Income</span>
            </div>
            <span className="text-xs py-1 px-2 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-full flex items-center">
              <ArrowUpRight size={12} className="mr-1" /> 8.7%
            </span>
          </div>
          <div className="mt-4">
            <h3 className="text-2xl font-semibold">${totalIncome.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h3>
            <span className="text-xs text-gray-500 dark:text-gray-400">This month</span>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="rounded-full p-3 bg-red-100 dark:bg-red-900/30 text-red-500 dark:text-red-400 mr-4">
                <ArrowDownRight size={20} />
              </div>
              <span className="text-sm text-gray-500 dark:text-gray-400">Expenses</span>
            </div>
            <span className="text-xs py-1 px-2 bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-full flex items-center">
              <ArrowDownRight size={12} className="mr-1" /> 4.3%
            </span>
          </div>
          <div className="mt-4">
            <h3 className="text-2xl font-semibold">${totalExpenses.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h3>
            <span className="text-xs text-gray-500 dark:text-gray-400">This month</span>
          </div>
        </div>
      </motion.div>
      
      <motion.div variants={itemVariants} className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left column - Accounts & Recent Transactions */}
        <div className="col-span-1 lg:col-span-3 space-y-6">
          {/* Accounts section */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
            <div className="flex justify-between items-center mb-5">
              <h2 className="text-xl font-semibold">Your Accounts</h2>
              <button className="flex items-center text-sm text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300">
                <Plus size={16} className="mr-1" /> Add Account
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {accounts.map(account => (
                <AccountCard 
                  key={account.id} 
                  account={account}
                  isSelected={selectedAccount === account.id}
                  onClick={() => setSelectedAccount(account.id)}
                />
              ))}
            </div>
          </div>
          
          {/* Spending Overview */}
          <SpendingOverview />
          
          {/* Recent Transactions */}
          <RecentTransactions transactions={recentTransactions} />
        </div>
        
        {/* Right column - Quick Actions & Upcoming */}
        <div className="col-span-1 space-y-6">
          {/* Quick Actions */}
          <QuickActions actions={quickActions} />
          
          {/* Upcoming */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
            <h2 className="text-lg font-semibold mb-4">Upcoming</h2>
            <div className="space-y-4">
              <div className="flex items-center p-3 rounded-lg border border-gray-200 dark:border-gray-700">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-500 dark:text-blue-400 mr-3">
                  <Calendar size={16} />
                </div>
                <div className="flex-1">
                  <h4 className="text-sm font-medium">Rent Payment</h4>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Due in 5 days • $1,200</p>
                </div>
              </div>
              <div className="flex items-center p-3 rounded-lg border border-gray-200 dark:border-gray-700">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center text-purple-500 dark:text-purple-400 mr-3">
                  <Calendar size={16} />
                </div>
                <div className="flex-1">
                  <h4 className="text-sm font-medium">Netflix Subscription</h4>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Due in 12 days • $13.99</p>
                </div>
              </div>
              <div className="flex items-center p-3 rounded-lg border border-gray-200 dark:border-gray-700">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center text-green-500 dark:text-green-400 mr-3">
                  <ArrowUpRight size={16} />
                </div>
                <div className="flex-1">
                  <h4 className="text-sm font-medium">Salary Deposit</h4>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Expected in 15 days</p>
                </div>
              </div>
            </div>
            <button className="mt-4 w-full text-center text-sm text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300">
              View all
            </button>
          </div>
          
          {/* Financial Goals */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
            <h2 className="text-lg font-semibold mb-4">Financial Goals</h2>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between items-center mb-1">
                  <h4 className="text-sm font-medium">Vacation Fund</h4>
                  <span className="text-xs font-medium">65%</span>
                </div>
                <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                  <div className="h-full bg-primary-600 rounded-full" style={{ width: '65%' }}></div>
                </div>
                <div className="flex justify-between mt-1">
                  <span className="text-xs text-gray-500 dark:text-gray-400">$1,950 saved</span>
                  <span className="text-xs text-gray-500 dark:text-gray-400">$3,000 goal</span>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-1">
                  <h4 className="text-sm font-medium">New Car</h4>
                  <span className="text-xs font-medium">25%</span>
                </div>
                <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                  <div className="h-full bg-secondary-500 rounded-full" style={{ width: '25%' }}></div>
                </div>
                <div className="flex justify-between mt-1">
                  <span className="text-xs text-gray-500 dark:text-gray-400">$5,000 saved</span>
                  <span className="text-xs text-gray-500 dark:text-gray-400">$20,000 goal</span>
                </div>
              </div>
            </div>
            <button className="mt-4 w-full text-sm py-2 bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 rounded-lg hover:bg-primary-100 dark:hover:bg-primary-900/30 transition-colors">
              Add New Goal
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default Dashboard;