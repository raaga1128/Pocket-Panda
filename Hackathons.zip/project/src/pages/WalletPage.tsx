import { useState } from 'react';
import { Plus, RefreshCw, PlusCircle, Smartphone, ChevronRight, Clock, Wallet, QrCode } from 'lucide-react';
import { motion } from 'framer-motion';

// Wallet type definition
interface DigitalWallet {
  id: string;
  name: string;
  type: string;
  logo: string;
  connected: boolean;
  balance?: number;
  transactions?: any[];
}

// Mock data for connected wallets
const wallets: DigitalWallet[] = [
  {
    id: '1',
    name: 'PhonePe',
    type: 'Mobile Wallet',
    logo: 'https://images.pexels.com/photos/5717479/pexels-photo-5717479.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    connected: true,
    balance: 1248.65,
    transactions: [
      { id: '1', title: 'Food Delivery', date: 'Jan 15, 2025', amount: -210.00 },
      { id: '2', title: 'Utility Bill', date: 'Jan 10, 2025', amount: -420.35 },
      { id: '3', title: 'Recharge', date: 'Jan 5, 2025', amount: -100.00 },
    ]
  },
  {
    id: '2',
    name: 'PayPal',
    type: 'Online Payment',
    logo: 'https://images.pexels.com/photos/5717479/pexels-photo-5717479.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    connected: true,
    balance: 537.42,
    transactions: [
      { id: '1', title: 'Online Purchase', date: 'Jan 12, 2025', amount: -45.99 },
      { id: '2', title: 'Freelance Payment', date: 'Jan 8, 2025', amount: 250.00 },
    ]
  }
];

// Available wallets to connect
const availableWallets: DigitalWallet[] = [
  {
    id: '3',
    name: 'Google Pay',
    type: 'Mobile Wallet',
    logo: 'https://images.pexels.com/photos/5717479/pexels-photo-5717479.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    connected: false
  },
  {
    id: '4',
    name: 'Apple Pay',
    type: 'Mobile Wallet',
    logo: 'https://images.pexels.com/photos/5717479/pexels-photo-5717479.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    connected: false
  },
  {
    id: '5',
    name: 'Venmo',
    type: 'Peer-to-Peer',
    logo: 'https://images.pexels.com/photos/5717479/pexels-photo-5717479.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    connected: false
  }
];

const WalletPage = () => {
  const [activeWallet, setActiveWallet] = useState<string | null>(wallets[0].id);
  const [showQRCode, setShowQRCode] = useState(false);
  
  const getActiveWallet = () => {
    return wallets.find(wallet => wallet.id === activeWallet);
  };
  
  const wallet = getActiveWallet();
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold">Digital Wallets</h1>
        <button className="flex items-center text-sm bg-primary-600 hover:bg-primary-700 text-white py-2 px-4 rounded-lg transition-colors">
          <Plus size={16} className="mr-1" /> Add Wallet
        </button>
      </div>
      
      {/* Wallets overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {wallets.map((w) => (
          <motion.div
            key={w.id}
            whileHover={{ y: -4, scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setActiveWallet(w.id)}
            className={`
              relative p-5 rounded-xl cursor-pointer transition-all duration-300
              bg-gradient-to-r from-primary-600 to-primary-500 text-white
              ${activeWallet === w.id 
                ? 'ring-2 ring-primary-300 shadow-md' 
                : 'hover:shadow-md'}
            `}
          >
            <div className="h-full flex flex-col justify-between">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-lg font-semibold">{w.name}</h3>
                  <p className="text-xs opacity-80 mt-1">{w.type}</p>
                </div>
                <div className="h-10 w-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                  <Smartphone size={20} className="text-white" />
                </div>
              </div>
              
              <div className="mt-6">
                <p className="text-sm opacity-80">Available Balance</p>
                <p className="text-2xl font-semibold mt-1">
                  ${w.balance?.toFixed(2)}
                </p>
              </div>
            </div>
            
            {/* Card decoration */}
            <div className="absolute top-0 right-0 h-full w-1/2 overflow-hidden pointer-events-none">
              <div 
                className="absolute inset-0 opacity-10" 
                style={{ 
                  background: 'radial-gradient(circle at 70% 30%, white 0%, transparent 70%)' 
                }}
              ></div>
            </div>
          </motion.div>
        ))}
        
        {/* Add wallet card */}
        <motion.div
          whileHover={{ y: -4, scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="relative p-5 rounded-xl cursor-pointer transition-all duration-300
            bg-white dark:bg-gray-800 border-2 border-dashed border-gray-300 dark:border-gray-700
            flex flex-col items-center justify-center text-center"
        >
          <div className="h-12 w-12 rounded-full bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center text-primary-600 dark:text-primary-400 mb-3">
            <PlusCircle size={24} />
          </div>
          <h3 className="text-lg font-semibold">Add New Wallet</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            Connect another payment method
          </p>
        </motion.div>
      </div>
      
      {/* Wallet details */}
      {wallet && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Transactions */}
          <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">{wallet.name} Transactions</h2>
                <button className="flex items-center text-sm text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300">
                  <RefreshCw size={16} className="mr-1" /> Refresh
                </button>
              </div>
            </div>
            
            <div className="divide-y divide-gray-200 dark:divide-gray-700">
              {wallet.transactions && wallet.transactions.length > 0 ? (
                wallet.transactions.map((transaction) => (
                  <div key={transaction.id} className="p-4 hover:bg-gray-50 dark:hover:bg-gray-750">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center mr-4">
                        <Clock size={20} className="text-gray-500 dark:text-gray-400" />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between">
                          <p className="text-sm font-medium truncate">{transaction.title}</p>
                          <p className={`text-sm font-medium ${
                            transaction.amount > 0 
                              ? 'text-green-600 dark:text-green-400' 
                              : 'text-red-600 dark:text-red-400'
                          }`}>
                            {transaction.amount > 0 ? '+' : ''}
                            ${Math.abs(transaction.amount).toFixed(2)}
                          </p>
                        </div>
                        <div className="flex justify-between">
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            {transaction.date}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-6 text-center">
                  <p className="text-gray-500 dark:text-gray-400">No transactions found</p>
                </div>
              )}
            </div>
            
            <div className="p-4 border-t border-gray-200 dark:border-gray-700">
              <button className="w-full text-center text-sm text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300">
                View all transactions
              </button>
            </div>
          </div>
          
          {/* Quick actions and settings */}
          <div className="space-y-6">
            {/* Quick actions */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
              <h2 className="text-lg font-semibold mb-4">Quick Actions</h2>
              <div className="grid grid-cols-2 gap-3">
                <motion.button
                  whileHover={{ y: -2 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => setShowQRCode(true)}
                  className="flex flex-col items-center justify-center p-4 rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  <div className="w-10 h-10 rounded-full bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center text-primary-600 dark:text-primary-400 mb-2">
                    <QrCode size={20} />
                  </div>
                  <span className="text-sm font-medium">Show QR Code</span>
                </motion.button>
                
                <motion.button
                  whileHover={{ y: -2 }}
                  whileTap={{ scale: 0.97 }}
                  className="flex flex-col items-center justify-center p-4 rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  <div className="w-10 h-10 rounded-full bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center text-primary-600 dark:text-primary-400 mb-2">
                    <Wallet size={20} />
                  </div>
                  <span className="text-sm font-medium">Add Money</span>
                </motion.button>
              </div>
            </div>
            
            {/* Connect more wallets */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
              <h2 className="text-lg font-semibold mb-4">Connect More Wallets</h2>
              <div className="space-y-3">
                {availableWallets.map((wallet) => (
                  <div 
                    key={wallet.id}
                    className="flex items-center justify-between p-3 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-750 cursor-pointer transition-colors"
                  >
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center mr-3">
                        <Smartphone size={20} className="text-gray-500 dark:text-gray-400" />
                      </div>
                      <div>
                        <h3 className="text-sm font-medium">{wallet.name}</h3>
                        <p className="text-xs text-gray-500 dark:text-gray-400">{wallet.type}</p>
                      </div>
                    </div>
                    <ChevronRight size={16} className="text-gray-400" />
                  </div>
                ))}
              </div>
            </div>
            
            {/* Wallet settings */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
              <h2 className="text-lg font-semibold mb-4">Wallet Settings</h2>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="text-sm font-medium">Instant Notifications</h3>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Get notified for all transactions
                    </p>
                  </div>
                  <div className="relative inline-block w-12 h-6 transition duration-200 ease-in-out rounded-full">
                    <input
                      type="checkbox"
                      id="notifications"
                      className="absolute w-0 h-0 opacity-0"
                      defaultChecked
                    />
                    <label
                      htmlFor="notifications"
                      className="flex items-center justify-between h-6 rounded-full cursor-pointer bg-primary-600"
                    >
                      <span className="block h-5 w-5 ml-0.5 bg-white rounded-full transform translate-x-6 transition-transform duration-200"></span>
                    </label>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="text-sm font-medium">Transaction Limits</h3>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Set maximum transaction amount
                    </p>
                  </div>
                  <button className="text-xs text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300">
                    Configure
                  </button>
                </div>
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="text-sm font-medium">Auto-Reload</h3>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Automatically add money when balance is low
                    </p>
                  </div>
                  <div className="relative inline-block w-12 h-6 transition duration-200 ease-in-out rounded-full">
                    <input
                      type="checkbox"
                      id="auto-reload"
                      className="absolute w-0 h-0 opacity-0"
                    />
                    <label
                      htmlFor="auto-reload"
                      className="flex items-center justify-between h-6 rounded-full cursor-pointer bg-gray-300 dark:bg-gray-600"
                    >
                      <span className="block h-5 w-5 ml-0.5 bg-white rounded-full transform transition-transform duration-200"></span>
                    </label>
                  </div>
                </div>
              </div>
              <button className="mt-4 w-full py-2 border border-primary-600 text-primary-600 dark:border-primary-400 dark:text-primary-400 rounded-lg hover:bg-primary-50 dark:hover:bg-primary-900/20 transition-colors text-sm font-medium">
                Manage Wallet Settings
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* QR Code Modal */}
      {showQRCode && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 max-w-sm w-full"
          >
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4">QR Code for {wallet?.name}</h3>
              <div className="bg-white p-4 rounded-lg mb-4 mx-auto w-48 h-48 flex items-center justify-center">
                <QrCode size={160} className="text-gray-800" />
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
                Scan this code to make a payment to your wallet
              </p>
              <button
                onClick={() => setShowQRCode(false)}
                className="w-full py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg transition-colors"
              >
                Close
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default WalletPage;