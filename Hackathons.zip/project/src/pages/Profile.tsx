import { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Lock, Bell, Shield, CreditCard, LogOut } from 'lucide-react';

// Mock user data
const user = {
  id: '1',
  name: 'John Doe',
  email: 'john.doe@example.com',
  phone: '+1 (555) 123-4567',
  address: '123 Main St, Anytown, CA 94010',
  profileImage: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
  memberSince: 'January 2023',
};

const Profile = () => {
  const [activeTab, setActiveTab] = useState('profile');
  const [isEditing, setIsEditing] = useState(false);
  
  const [formData, setFormData] = useState({
    name: user.name,
    email: user.email,
    phone: user.phone,
    address: user.address,
  });
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would send the data to an API
    setIsEditing(false);
  };
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden">
        <div className="md:flex">
          {/* Sidebar */}
          <div className="md:w-64 border-r border-gray-200 dark:border-gray-700">
            <div className="p-6 text-center">
              <div className="relative inline-block">
                <img
                  src={user.profileImage}
                  alt={user.name}
                  className="h-24 w-24 rounded-full object-cover mx-auto"
                />
                <button className="absolute bottom-0 right-0 bg-primary-600 text-white rounded-full p-1.5 shadow-md hover:bg-primary-700 transition-colors">
                  <User size={14} />
                </button>
              </div>
              <h2 className="mt-4 text-xl font-semibold">{user.name}</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Member since {user.memberSince}</p>
            </div>
            
            <div className="py-3">
              <button
                onClick={() => setActiveTab('profile')}
                className={`w-full text-left px-6 py-3 flex items-center text-sm font-medium ${
                  activeTab === 'profile'
                    ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 border-l-4 border-primary-600 dark:border-primary-400'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-750'
                }`}
              >
                <User size={18} className="mr-3" />
                Personal Information
              </button>
              
              <button
                onClick={() => setActiveTab('security')}
                className={`w-full text-left px-6 py-3 flex items-center text-sm font-medium ${
                  activeTab === 'security'
                    ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 border-l-4 border-primary-600 dark:border-primary-400'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-750'
                }`}
              >
                <Lock size={18} className="mr-3" />
                Security & Login
              </button>
              
              <button
                onClick={() => setActiveTab('notifications')}
                className={`w-full text-left px-6 py-3 flex items-center text-sm font-medium ${
                  activeTab === 'notifications'
                    ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 border-l-4 border-primary-600 dark:border-primary-400'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-750'
                }`}
              >
                <Bell size={18} className="mr-3" />
                Notifications
              </button>
              
              <button
                onClick={() => setActiveTab('privacy')}
                className={`w-full text-left px-6 py-3 flex items-center text-sm font-medium ${
                  activeTab === 'privacy'
                    ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 border-l-4 border-primary-600 dark:border-primary-400'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-750'
                }`}
              >
                <Shield size={18} className="mr-3" />
                Privacy
              </button>
              
              <button
                onClick={() => setActiveTab('payment')}
                className={`w-full text-left px-6 py-3 flex items-center text-sm font-medium ${
                  activeTab === 'payment'
                    ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 border-l-4 border-primary-600 dark:border-primary-400'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-750'
                }`}
              >
                <CreditCard size={18} className="mr-3" />
                Payment Methods
              </button>
              
              <div className="px-6 pt-6 mt-6 border-t border-gray-200 dark:border-gray-700">
                <button className="flex items-center text-sm text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300">
                  <LogOut size={18} className="mr-3" />
                  Sign Out
                </button>
              </div>
            </div>
          </div>
          
          {/* Main content */}
          <div className="p-6 flex-1">
            {activeTab === 'profile' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-semibold">Personal Information</h2>
                  
                  {!isEditing ? (
                    <button
                      onClick={() => setIsEditing(true)}
                      className="text-sm text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 font-medium"
                    >
                      Edit Profile
                    </button>
                  ) : (
                    <button
                      onClick={() => setIsEditing(false)}
                      className="text-sm text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 font-medium"
                    >
                      Cancel
                    </button>
                  )}
                </div>
                
                {!isEditing ? (
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Full Name</h3>
                      <p className="font-medium">{user.name}</p>
                    </div>
                    
                    <div>
                      <h3 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Email Address</h3>
                      <p className="font-medium">{user.email}</p>
                    </div>
                    
                    <div>
                      <h3 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Phone Number</h3>
                      <p className="font-medium">{user.phone}</p>
                    </div>
                    
                    <div>
                      <h3 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Address</h3>
                      <p className="font-medium">{user.address}</p>
                    </div>
                    
                    <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                      <h3 className="text-sm font-medium mb-2">Connected Accounts</h3>
                      
                      <div className="space-y-3">
                        <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-750 rounded-lg">
                          <div className="flex items-center">
                            <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-500 dark:text-blue-400 mr-3">
                              <span className="text-lg">G</span>
                            </div>
                            <div>
                              <p className="text-sm font-medium">Google</p>
                              <p className="text-xs text-gray-500 dark:text-gray-400">Connected</p>
                            </div>
                          </div>
                          <button className="text-xs text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300">
                            Disconnect
                          </button>
                        </div>
                        
                        <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-750 rounded-lg">
                          <div className="flex items-center">
                            <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-500 dark:text-blue-400 mr-3">
                              <span className="text-lg">F</span>
                            </div>
                            <div>
                              <p className="text-sm font-medium">Facebook</p>
                              <p className="text-xs text-gray-500 dark:text-gray-400">Not connected</p>
                            </div>
                          </div>
                          <button className="text-xs text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300">
                            Connect
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                      <label htmlFor="name" className="block text-sm text-gray-500 dark:text-gray-400 mb-1">
                        Full Name
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 dark:focus:ring-primary-400 bg-white dark:bg-gray-700"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="email" className="block text-sm text-gray-500 dark:text-gray-400 mb-1">
                        Email Address
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 dark:focus:ring-primary-400 bg-white dark:bg-gray-700"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="phone" className="block text-sm text-gray-500 dark:text-gray-400 mb-1">
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 dark:focus:ring-primary-400 bg-white dark:bg-gray-700"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="address" className="block text-sm text-gray-500 dark:text-gray-400 mb-1">
                        Address
                      </label>
                      <input
                        type="text"
                        id="address"
                        name="address"
                        value={formData.address}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 dark:focus:ring-primary-400 bg-white dark:bg-gray-700"
                      />
                    </div>
                    
                    <div className="flex justify-end pt-4">
                      <button
                        type="submit"
                        className="px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg transition-colors"
                      >
                        Save Changes
                      </button>
                    </div>
                  </form>
                )}
              </motion.div>
            )}
            
            {activeTab === 'security' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
                <h2 className="text-xl font-semibold">Security & Login</h2>
                
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-3">Change Password</h3>
                    <form className="space-y-4">
                      <div>
                        <label htmlFor="current-password" className="block text-sm text-gray-500 dark:text-gray-400 mb-1">
                          Current Password
                        </label>
                        <input
                          type="password"
                          id="current-password"
                          className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 dark:focus:ring-primary-400 bg-white dark:bg-gray-700"
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="new-password" className="block text-sm text-gray-500 dark:text-gray-400 mb-1">
                          New Password
                        </label>
                        <input
                          type="password"
                          id="new-password"
                          className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 dark:focus:ring-primary-400 bg-white dark:bg-gray-700"
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="confirm-password" className="block text-sm text-gray-500 dark:text-gray-400 mb-1">
                          Confirm New Password
                        </label>
                        <input
                          type="password"
                          id="confirm-password"
                          className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 dark:focus:ring-primary-400 bg-white dark:bg-gray-700"
                        />
                      </div>
                      
                      <div className="flex justify-end">
                        <button
                          type="submit"
                          className="px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg transition-colors"
                        >
                          Update Password
                        </button>
                      </div>
                    </form>
                  </div>
                  
                  <div className="pt-6 border-t border-gray-200 dark:border-gray-700">
                    <h3 className="text-lg font-medium mb-3">Two-Factor Authentication</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                      Add an extra layer of security to your account by enabling two-factor authentication.
                    </p>
                    
                    <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-750 rounded-lg">
                      <div>
                        <p className="text-sm font-medium">Two-Factor Authentication</p>
                        <p className="text-xs text-green-600 dark:text-green-400">Enabled</p>
                      </div>
                      <button className="text-sm text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300">
                        Manage
                      </button>
                    </div>
                  </div>
                  
                  <div className="pt-6 border-t border-gray-200 dark:border-gray-700">
                    <h3 className="text-lg font-medium mb-3">Login Sessions</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                      These are the devices that are currently logged into your account.
                    </p>
                    
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-750 rounded-lg">
                        <div>
                          <p className="text-sm font-medium">MacBook Pro - Chrome</p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            New York, USA - Current session
                          </p>
                        </div>
                        <span className="text-xs py-1 px-2 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-full">
                          Active
                        </span>
                      </div>
                      
                      <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-750 rounded-lg">
                        <div>
                          <p className="text-sm font-medium">iPhone 13 - Safari</p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            San Francisco, USA - 2 days ago
                          </p>
                        </div>
                        <button className="text-xs text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300">
                          Logout
                        </button>
                      </div>
                    </div>
                    
                    <button className="mt-4 text-sm text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300">
                      Logout of all devices
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
            
            {activeTab === 'notifications' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
                <h2 className="text-xl font-semibold">Notification Preferences</h2>
                
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-3">Email Notifications</h3>
                    
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-750 rounded-lg">
                        <div>
                          <p className="text-sm font-medium">Account Activity</p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            Receive emails about your account activity and security
                          </p>
                        </div>
                        <div className="relative inline-block w-12 h-6 transition duration-200 ease-in-out rounded-full">
                          <input
                            type="checkbox"
                            id="account-activity"
                            className="absolute w-0 h-0 opacity-0"
                            defaultChecked
                          />
                          <label
                            htmlFor="account-activity"
                            className="flex items-center justify-between h-6 rounded-full cursor-pointer bg-primary-600"
                          >
                            <span className="block h-5 w-5 ml-0.5 bg-white rounded-full transform translate-x-6 transition-transform duration-200"></span>
                          </label>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-750 rounded-lg">
                        <div>
                          <p className="text-sm font-medium">Transaction Updates</p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            Receive emails for transactions, payments, and transfers
                          </p>
                        </div>
                        <div className="relative inline-block w-12 h-6 transition duration-200 ease-in-out rounded-full">
                          <input
                            type="checkbox"
                            id="transaction-updates"
                            className="absolute w-0 h-0 opacity-0"
                            defaultChecked
                          />
                          <label
                            htmlFor="transaction-updates"
                            className="flex items-center justify-between h-6 rounded-full cursor-pointer bg-primary-600"
                          >
                            <span className="block h-5 w-5 ml-0.5 bg-white rounded-full transform translate-x-6 transition-transform duration-200"></span>
                          </label>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-750 rounded-lg">
                        <div>
                          <p className="text-sm font-medium">Marketing Updates</p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            Receive emails about new features, promotions, and news
                          </p>
                        </div>
                        <div className="relative inline-block w-12 h-6 transition duration-200 ease-in-out rounded-full">
                          <input
                            type="checkbox"
                            id="marketing-updates"
                            className="absolute w-0 h-0 opacity-0"
                          />
                          <label
                            htmlFor="marketing-updates"
                            className="flex items-center justify-between h-6 rounded-full cursor-pointer bg-gray-300 dark:bg-gray-600"
                          >
                            <span className="block h-5 w-5 ml-0.5 bg-white rounded-full transform transition-transform duration-200"></span>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="pt-6 border-t border-gray-200 dark:border-gray-700">
                    <h3 className="text-lg font-medium mb-3">Push Notifications</h3>
                    
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-750 rounded-lg">
                        <div>
                          <p className="text-sm font-medium">Transaction Alerts</p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            Receive push notifications for all transactions
                          </p>
                        </div>
                        <div className="relative inline-block w-12 h-6 transition duration-200 ease-in-out rounded-full">
                          <input
                            type="checkbox"
                            id="transaction-alerts"
                            className="absolute w-0 h-0 opacity-0"
                            defaultChecked
                          />
                          <label
                            htmlFor="transaction-alerts"
                            className="flex items-center justify-between h-6 rounded-full cursor-pointer bg-primary-600"
                          >
                            <span className="block h-5 w-5 ml-0.5 bg-white rounded-full transform translate-x-6 transition-transform duration-200"></span>
                          </label>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-750 rounded-lg">
                        <div>
                          <p className="text-sm font-medium">Security Alerts</p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            Receive push notifications for security-related events
                          </p>
                        </div>
                        <div className="relative inline-block w-12 h-6 transition duration-200 ease-in-out rounded-full">
                          <input
                            type="checkbox"
                            id="security-alerts"
                            className="absolute w-0 h-0 opacity-0"
                            defaultChecked
                          />
                          <label
                            htmlFor="security-alerts"
                            className="flex items-center justify-between h-6 rounded-full cursor-pointer bg-primary-600"
                          >
                            <span className="block h-5 w-5 ml-0.5 bg-white rounded-full transform translate-x-6 transition-transform duration-200"></span>
                          </label>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-750 rounded-lg">
                        <div>
                          <p className="text-sm font-medium">App Updates</p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            Receive push notifications for app updates and new features
                          </p>
                        </div>
                        <div className="relative inline-block w-12 h-6 transition duration-200 ease-in-out rounded-full">
                          <input
                            type="checkbox"
                            id="app-updates"
                            className="absolute w-0 h-0 opacity-0"
                          />
                          <label
                            htmlFor="app-updates"
                            className="flex items-center justify-between h-6 rounded-full cursor-pointer bg-gray-300 dark:bg-gray-600"
                          >
                            <span className="block h-5 w-5 ml-0.5 bg-white rounded-full transform transition-transform duration-200"></span>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
            
            {/* Other tabs would go here with similar structure */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;