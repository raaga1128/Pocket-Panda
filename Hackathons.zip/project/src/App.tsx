import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';

// Layout Components
import DashboardLayout from './components/layout/DashboardLayout';

// Pages
import Dashboard from './pages/Dashboard';
import Accounts from './pages/Accounts';
import Transactions from './pages/Transactions';
import WalletPage from './pages/WalletPage';
import Profile from './pages/Profile';
import LoginPage from './pages/LoginPage';

// Utils
import { ThemeProvider } from './context/ThemeContext';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  
  // Check if user is logged in
  useEffect(() => {
    // In a real app, you would verify token validity
    const token = localStorage.getItem('auth_token');
    setIsAuthenticated(!!token);
  }, []);

  // For demo purposes, create a login function
  const handleLogin = (credentials: { email: string; password: string }) => {
    // This is just for demo - in a real app, you would validate credentials with a backend
    if (credentials.email && credentials.password) {
      localStorage.setItem('auth_token', 'demo_token');
      setIsAuthenticated(true);
      return true;
    }
    return false;
  };

  const handleLogout = () => {
    localStorage.removeItem('auth_token');
    setIsAuthenticated(false);
  };

  return (
    <ThemeProvider>
      <Router>
        <AnimatePresence mode="wait">
          <Routes>
            {!isAuthenticated ? (
              <>
                <Route 
                  path="/login" 
                  element={<LoginPage onLogin={handleLogin} />} 
                />
                <Route
                  path="*"
                  element={<Navigate to="/login" replace />}
                />
              </>
            ) : (
              <>
                <Route path="/" element={<DashboardLayout onLogout={handleLogout} />}>
                  <Route index element={<Dashboard />} />
                  <Route path="accounts" element={<Accounts />} />
                  <Route path="transactions" element={<Transactions />} />
                  <Route path="wallet" element={<WalletPage />} />
                  <Route path="profile" element={<Profile />} />
                </Route>
                <Route 
                  path="*" 
                  element={<Navigate to="/" replace />} 
                />
              </>
            )}
          </Routes>
        </AnimatePresence>
      </Router>
    </ThemeProvider>
  );
}

export default App;