// Account type
export interface Account {
  id: string;
  name: string;
  type: 'checking' | 'savings' | 'investment' | string;
  balance: number;
  number: string;
  color: string;
}

// Transaction type
export interface Transaction {
  id: string;
  title: string;
  date: Date;
  amount: number;
  category: string;
  icon?: string;
  description?: string;
  account?: string;
}

// User type
export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  profileImage?: string;
  memberSince: string;
}

// Digital wallet type
export interface DigitalWallet {
  id: string;
  name: string;
  type: string;
  logo: string;
  connected: boolean;
  balance?: number;
  transactions?: {
    id: string;
    title: string;
    date: string;
    amount: number;
  }[];
}